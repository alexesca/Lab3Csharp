﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3
{
    public class Classes
    {
        public double average { get { return avg; } }
        private double avg = 0;

        public List<Assingments> listAssignments = new List<Assingments>();

        public Classes(List<Student> list)
        {
            for (int i = 0; i < 5; i++)
            {
                Assingments assignment = new Assingments(list,i);
                listAssignments.Add(assignment);
                
            }
            this.calculateClassAverage();
        }

        public void calculateClassAverage()
        {
            double avg = 0;
            foreach (var assingment in this.listAssignments)
            {
                avg += assingment.average;
            }
            avg /= this.listAssignments.Count;
            this.avg = Math.Round(avg);
        }
    }

    public class Assingments 
    {
        public double average { get { return avg; } }
        private double avg = 0;

        public Assingments(List<Student> list, int i) : base()
        {
               this.calculateAssignmentAverage(list,i);
        }

        public void calculateAssignmentAverage(List<Student> list, int i)
        {
            double avg = 0;
            foreach (var student in list)
            {
                avg += student.grades[i];
            }
            avg /= list.Count;
            this.avg = Math.Round(avg); 
        }

    }
}
