﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3
{
    /* Create student class that carries an ID of a name
        * and a list of grades from different assignments */
    public class Student
    {
        public List<Int32> grades = new List<Int32>();
        public string name { set; get; }
        public string firstName { set; get; }
        public string lastName { set; get; }
        public double gpa { set; get; }

        public Student(string name, List<Int32> grades)
        {
            this.name = name;
            this.grades = grades;
            formatName();
        }

        //formats the name 
        public void formatName()
        {
            List<string> words = this.name.Split(' ').ToList<string>();
            this.firstName = words.First();
            this.lastName = words.Last();
        }

        // Calculate each student's individual average
        public double getStudentAverage(Student student)
        {
            double total = 0;

            foreach (int grade in student.grades)
                total += grade;

            double studentAverage = total / student.grades.Count;
            return studentAverage;
        }

        // Calculate class average for each assignment
        public  double[] getAssignmentAverage(List<Student> list)
        {
            double[] totals = new double[5];

            for (int j = 0; j < list[0].grades.Count; j++)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    totals[j] += list[i].grades[j];
                }
                totals[j] /= list.Count;
            }
            return totals;
        }

        // Calculate overall class average
        public double getClassAverage(List<Student> list)
        {
            double total = 0;

            foreach (Student stu in list)
                total += getStudentAverage(stu);

            double classAverage = total / list.Count;
            return classAverage;
        }

        public static void studentAverage(List<Student> students)
        {

            foreach (var student in students)
            {
                double gpa = 0;
                for (int i = 0; i < student.grades.Count; i++)
                {
                    gpa += student.grades[i];
                }
                gpa /= student.grades.Count;
                student.gpa = Math.Round(gpa);
            }
        }
    }
}
