﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lab3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3.Tests
{
    [TestClass()]
    public class ClassesTests
    {
        [TestMethod()]
        public void ClassesTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void calculateClassAverageTest()
        {
            Assert.Fail();
        }
    }
}