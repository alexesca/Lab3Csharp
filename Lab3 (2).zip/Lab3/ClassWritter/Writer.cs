﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Lab3
{
    public class WriteFile
    {
        private List<Student> list = new List<Student>();
        string outputFile;
        public WriteFile(List<Student> list, string outputFile)
        {
            this.list = list;
            this.outputFile = outputFile;
        }

        public void writeToFile()
        {

            using (StreamWriter writer = new StreamWriter(outputFile))
            {
                writer.WriteLine("Lastname, Firstname, avgGD");

                foreach (var student in list)
                {
                    writer.Write("{0},{1}{2}",student.lastName, student.firstName,',');
                    writer.WriteLine(student.gpa.ToString("f2"));
                }
                // Write last line of file
                writer.Write("AVERAGES,");
                //Calculating avg student
                Classes classes = new Classes(list);
                for (int i = 0; i < classes.listAssignments.Count; i++)
                {
                    writer.Write(classes.listAssignments[i].average.ToString("f2") + ',');
                }
                writer.Write(classes.average.ToString("f2"));
            }
        }
    }
}




