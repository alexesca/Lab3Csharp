﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using Lab3;
namespace Lab3
{
    public class Calculator
    {
        
    }
}
