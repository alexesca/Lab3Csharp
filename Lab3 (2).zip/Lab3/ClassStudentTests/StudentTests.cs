﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lab3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3.Tests
{
    [TestClass()]
    public class StudentTests
    {
        [TestMethod()]
        public void StudentTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void formatNameTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void getStudentAverageTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void getAssignmentAverageTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void getClassAverageTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void studentAverageTest()
        {
            Assert.Fail();
        }
    }
}