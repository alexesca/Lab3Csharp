﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lab3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3.Tests
{
    [TestClass()]
    public class ReaderTests
    {
        [TestMethod()]
        public void checkIfFileExistsTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void checkIfFileMayBeCreatedTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void readFileTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void getNameTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void getGradesTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void splitStringLineTest()
        {
            Assert.Fail();
        }
    }
}